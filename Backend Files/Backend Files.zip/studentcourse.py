# from flask import Flask
# from flask_sqlalchemy import SQLAlchemy
# from database import create_app

# app, db = create_app()

# class StudentCourses(db.Model):

#     sno = db.Model(db.Integer, primary_key=True, nullable=False, autoincrement=True)
#     student_id = db.Model(db.String(50),nullable=False)
#     course_id = db.Model(db.String(50), nullable=False)

#     def __init__(self,course,):        super().__init__()



